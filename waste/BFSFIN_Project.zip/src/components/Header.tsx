"use client";

import Link from "next/link";
import { useState } from "react";
import { ShieldCheck, PhoneCall, ChevronDown, Menu, X, ArrowRight, UserCheck, Briefcase, Lock, Home, TrendingUp, Calculator } from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [portalDropdownOpen, setPortalDropdownOpen] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<string | null>(null);

  const toggleAccordion = (menu: string) => {
    setOpenAccordion(openAccordion === menu ? null : menu);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
    setOpenAccordion(null);
  };

  return (
    <>
      <header className="sticky top-0 z-50 glass-panel border-b border-emerald-500/20 shadow-xl transition-colors duration-200">
        {/* Top Banner Ticker / Call strip */}
        <div className="hidden md:flex bg-slate-50 dark:bg-gradient-to-r dark:from-slate-900 dark:via-emerald-950 dark:to-blue-950 px-4 py-1.5 text-xs text-slate-700 dark:text-slate-300 justify-between items-center border-b border-slate-200 dark:border-emerald-500/10 transition-colors duration-300">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" /> RBI Compliant &amp; Certified Broker
            </span>
            <span className="hidden md:inline text-slate-300 dark:text-slate-500">|</span>
            <span className="hidden md:inline text-slate-600 dark:text-slate-300">
              ⚡ Fastest Home Loan Approval (5 Days Guarantee)
            </span>
          </div>
          <div className="flex items-center gap-4">
            <a href="tel:7900979001" className="flex items-center gap-1 text-emerald-700 dark:text-emerald-400 hover:text-emerald-600 dark:hover:text-emerald-300 transition">
              <PhoneCall className="w-3 h-3" /> <span className="font-semibold">7900-979-001</span>
            </a>
            <span className="hidden sm:inline text-slate-300 dark:text-slate-500">|</span>
            
            <div className="flex items-center gap-3">
              <div className="relative">
                <button
                  onClick={() => setPortalDropdownOpen(!portalDropdownOpen)}
                  className="flex items-center gap-1.5 bg-blue-50 dark:bg-blue-900/60 text-blue-700 dark:text-blue-200 px-2.5 py-0.5 rounded-full text-[11px] font-medium border border-blue-200 dark:border-blue-500/30 hover:bg-blue-100 dark:hover:bg-blue-800/80 transition"
                >
                  <Lock className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                  <span>Login Portals</span>
                  <ChevronDown className="w-3 h-3" />
                </button>

                {portalDropdownOpen && (
                  <div className="absolute right-0 mt-1 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-emerald-500/30 rounded-xl shadow-2xl z-50 py-1 text-xs">
                    <Link href="/portal/customer" onClick={() => setPortalDropdownOpen(false)} className="flex items-center gap-2 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-900/40 hover:text-emerald-600 dark:hover:text-emerald-400 transition">
                      <UserCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> Client Dashboard
                    </Link>
                    <Link href="/portal/status" onClick={() => setPortalDropdownOpen(false)} className="flex items-center gap-2 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition">
                      <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" /> Application Tracker
                    </Link>
                    <Link href="/portal/partner" onClick={() => setPortalDropdownOpen(false)} className="flex items-center gap-2 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-900/40 hover:text-emerald-600 dark:hover:text-emerald-400 transition">
                      <Briefcase className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> Partner / DSA Login
                    </Link>
                    <Link href="/admin/dashboard" onClick={() => setPortalDropdownOpen(false)} className="flex items-center gap-2 px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition border-t border-slate-100 dark:border-slate-700/50">
                      <Lock className="w-4 h-4 text-blue-600 dark:text-blue-400" /> Bank Executive Login
                    </Link>
                  </div>
                )}
              </div>
              
              <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 hidden sm:block"></div>
              
              <ThemeToggle />
            </div>
          </div>
        </div>

        {/* Main Navigation */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo & Brand Name */}
            <Link href="/" className="flex items-center gap-2.5 group shrink-0 pr-4">
              <div className="relative h-10 bg-white rounded-lg px-2 py-1 shadow-sm border border-emerald-500/20 group-hover:border-emerald-400 transition-all duration-300">
                <img src="/logo.png" alt="Bhardwaj Financial Services Logo" className="h-full w-auto object-contain" />
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-lg font-black text-[#1f4e79] dark:text-[#3a86c6] leading-none tracking-tight">Bhardwaj Finance</span>
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 tracking-widest uppercase mt-0.5">Services</span>
              </div>
            </Link>

            {/* Desktop Nav Links */}
            <nav className="hidden xl:flex items-center gap-5 text-[13px] font-semibold dark:text-slate-200 text-slate-700">
              <Link href="/" className="hover:text-blue-700 dark:hover:text-emerald-400 transition">Home</Link>

              {/* Products Mega Menu */}
              <div className="relative group py-4">
                <button className="flex items-center gap-1 hover:text-emerald-600 dark:hover:text-emerald-400 transition">
                  <span>Products</span>
                  <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
                </button>
                <div className="absolute left-1/2 -translate-x-1/2 top-[52px] hidden group-hover:block w-[750px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-emerald-500/30 rounded-2xl shadow-2xl p-6 z-50">
                  <div className="grid grid-cols-3 gap-8 text-left">
                    <div className="space-y-3">
                      <h4 className="font-extrabold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2 mb-3">Housing Loans</h4>
                      <Link href="/products/home-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Home Loan</Link>
                      <Link href="/products/balance-transfer" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Balance Transfer</Link>
                      <Link href="/products/top-up-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Top-Up Loan</Link>
                      <Link href="/products/plot-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Plot / Land Purchase</Link>
                      <Link href="/products/construction-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Construction Loan</Link>
                    </div>
                    <div className="space-y-3">
                      <h4 className="font-extrabold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2 mb-3">Property & Retail</h4>
                      <Link href="/products/loan-against-property" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Loan Against Property</Link>
                      <Link href="/products/home-renovation" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Home Renovation</Link>
                      <Link href="/products/nri-home-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">NRI Home Loan</Link>
                      <Link href="/products/personal-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Personal Loan</Link>
                      <Link href="/products/education-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Education Loan</Link>
                    </div>
                    <div className="space-y-3">
                      <h4 className="font-extrabold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2 mb-3">Business & Auto</h4>
                      <Link href="/products/business-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Business / MSME Loan</Link>
                      <Link href="/products/working-capital" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Working Capital</Link>
                      <Link href="/products/loan-against-securities" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Loan Against Securities</Link>
                      <Link href="/products/car-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Car Loan</Link>
                      <Link href="/products/gold-loan" className="block text-slate-600 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">Gold Loan</Link>
                    </div>
                  </div>
                </div>
              </div>

              {/* Compare Banks */}
              <div className="relative group py-4">
                <button className="flex items-center gap-1 hover:text-blue-700 dark:hover:text-emerald-400 transition">
                  <span>Compare</span>
                  <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
                </button>
                <div className="absolute left-0 top-[52px] hidden group-hover:block w-60 bg-white dark:bg-slate-900 border border-slate-200 dark:border-emerald-500/30 rounded-xl shadow-2xl p-3 z-50 text-left">
                  <Link href="/rates" className="block px-3 py-2 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-slate-700 dark:text-slate-300 font-bold text-emerald-600 dark:text-emerald-400 transition">Live Bank Rates 🟢</Link>
                  <div className="my-1 border-t border-slate-100 dark:border-slate-800" />
                  <Link href="/compare/interest-rates" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Interest Rate Table</Link>
                  <Link href="/compare/processing-fees" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Processing Fees</Link>
                  <div className="my-1 border-t border-slate-100 dark:border-slate-800" />
                  <Link href="/banks/pnb" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">PNB Home Loan</Link>
                  <Link href="/banks/hdfc" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">HDFC Home Loan</Link>
                  <Link href="/banks/icici" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">ICICI Home Loan</Link>
                  <Link href="/banks/central-bank" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Central Bank Loan</Link>
                </div>
              </div>

              {/* Tools */}
              <div className="relative group py-4">
                <button className="flex items-center gap-1 hover:text-emerald-600 dark:hover:text-emerald-400 transition">
                  <span>Tools</span>
                  <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
                </button>
                <div className="absolute left-0 top-[52px] hidden group-hover:block w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-emerald-500/30 rounded-xl shadow-2xl p-3 z-50 text-left">
                  <Link href="/calculator" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">EMI Calculator</Link>
                  <Link href="/eligibility" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Eligibility Calculator</Link>
                  <Link href="/tools/interest-rate-compare" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Interest Rate Comparison</Link>
                  <Link href="/tools/balance-transfer" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Loan Balance Transfer</Link>
                  <Link href="/tools/prepayment" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Prepayment Calculator</Link>
                  <Link href="/tools/stamp-duty" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Stamp Duty Calculator</Link>
                  <Link href="/tools/tax-benefit" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Income Tax Benefit Tool</Link>
                  <Link href="/tools/affordability" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Affordability Checker</Link>
                </div>
              </div>

              {/* Resources */}
              <div className="relative group py-4">
                <button className="flex items-center gap-1 hover:text-blue-700 dark:hover:text-emerald-400 transition">
                  <span>Resources</span>
                  <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
                </button>
                <div className="absolute left-0 top-[52px] hidden group-hover:block w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-emerald-500/30 rounded-xl shadow-2xl p-3 z-50 text-left">
                  <Link href="/blog" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition font-bold">Blog & Articles</Link>
                  <Link href="/resources/documents" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Documents Required</Link>
                  <Link href="/resources/process" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Loan Process Guide</Link>
                  <Link href="/resources/credit-score" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Credit Score Guide</Link>
                  <Link href="/faq" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">FAQs</Link>
                  <Link href="/resources/downloads" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Downloads & Forms</Link>
                  <div className="my-1 border-t border-slate-100 dark:border-slate-800" />
                  <Link href="/testimonials" className="block px-3 py-2 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 transition">Success Stories</Link>
                </div>
              </div>

              {/* About Us */}
              <div className="relative group py-4">
                <button className="flex items-center gap-1 hover:text-emerald-600 dark:hover:text-emerald-400 transition">
                  <span>About Us</span>
                  <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
                </button>
                <div className="absolute left-0 top-[52px] hidden group-hover:block w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-emerald-500/30 rounded-xl shadow-2xl p-3 z-50 text-left">
                  <Link href="/about" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Our Story</Link>
                  <Link href="/about/founder" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Founder & Team</Link>
                  <Link href="/about/why-us" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Why Choose Us</Link>
                  <Link href="/about/certifications" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">RBI Registrations</Link>
                  <Link href="/careers" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Careers</Link>
                </div>
              </div>

              {/* Contact */}
              <div className="relative group py-4">
                <button className="flex items-center gap-1 hover:text-blue-700 dark:hover:text-emerald-400 transition">
                  <span>Contact</span>
                  <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
                </button>
                <div className="absolute right-0 top-[52px] hidden group-hover:block w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-emerald-500/30 rounded-xl shadow-2xl p-3 z-50 text-left">
                  <Link href="/contact" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Contact Form</Link>
                  <Link href="/contact/locations" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Office Locations</Link>
                  <Link href="/apply" className="block px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400 transition">Book Appointment</Link>
                </div>
              </div>
            </nav>

            {/* Apply Action Button (Desktop Only) */}
            <div className="hidden xl:flex items-center gap-4 shrink-0 pl-2">
              <Link
                href="/apply"
                className="relative inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-blue-600 hover:from-emerald-400 hover:to-blue-500 text-white font-bold px-4 py-2 rounded-xl shadow-lg shadow-emerald-500/25 transition transform hover:-translate-y-0.5 text-sm"
              >
                <span>Apply Now</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Mobile Top Header (only shows Theme Toggle now, menu moved to bottom nav) */}
            <div className="flex items-center gap-2 xl:hidden">
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Bottom Navigation Bar */}
      <div className="xl:hidden fixed bottom-0 left-0 w-full bg-white dark:bg-[#0f172a] border-t border-slate-200 dark:border-slate-800 z-[100] pb-safe flex justify-around items-center h-16 shadow-[0_-10px_20px_-10px_rgba(0,0,0,0.1)] transition-colors duration-300">
        <Link href="/" onClick={closeMobileMenu} className="flex flex-col items-center justify-center w-full h-full text-slate-500 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">
          <Home className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-bold">Home</span>
        </Link>
        <Link href="/rates" onClick={closeMobileMenu} className="flex flex-col items-center justify-center w-full h-full text-slate-500 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">
          <TrendingUp className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-bold">Rates</span>
        </Link>
        <Link href="/calculator" onClick={closeMobileMenu} className="flex flex-col items-center justify-center w-full h-full text-slate-500 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">
          <Calculator className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-bold">EMI</span>
        </Link>
        <button onClick={() => setMobileMenuOpen(true)} className="flex flex-col items-center justify-center w-full h-full text-slate-500 dark:text-slate-400 hover:text-emerald-500 dark:hover:text-emerald-400 transition">
          <Menu className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-bold">Menu</span>
        </button>
      </div>

      {/* Mobile Bottom Sheet Menu (Accordions) */}
      {mobileMenuOpen && (
        <div className="xl:hidden fixed inset-0 z-[110] flex flex-col justify-end">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" onClick={closeMobileMenu}></div>
          
          {/* Sheet */}
          <div className="relative w-full bg-white dark:bg-[#0f172a] rounded-t-3xl shadow-2xl max-h-[85vh] flex flex-col transform transition-transform duration-300 animate-in slide-in-from-bottom">
            {/* Header of sheet */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
              <h3 className="font-black text-lg text-slate-900 dark:text-white">Main Menu</h3>
              <button onClick={closeMobileMenu} className="p-2 bg-slate-100 dark:bg-slate-800 rounded-full text-slate-500 hover:text-red-500 transition">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="overflow-y-auto px-4 py-4 space-y-1 pb-24">
              
              {/* Mobile Contact & Login (Moved from Top Banner) */}
              <div className="flex gap-2 mb-4">
                <a href="tel:7900979001" className="flex-1 flex flex-col items-center justify-center gap-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 py-3 rounded-xl border border-emerald-200 dark:border-emerald-800/30 hover:bg-emerald-100 transition-colors">
                  <PhoneCall className="w-5 h-5" />
                  <span className="text-xs font-bold">Call Us</span>
                </a>
                <Link href="/portal/customer" onClick={closeMobileMenu} className="flex-1 flex flex-col items-center justify-center gap-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 py-3 rounded-xl border border-blue-200 dark:border-blue-800/30 hover:bg-blue-100 transition-colors">
                  <UserCheck className="w-5 h-5" />
                  <span className="text-xs font-bold">Client Login</span>
                </Link>
                <Link href="/portal/partner" onClick={closeMobileMenu} className="flex-1 flex flex-col items-center justify-center gap-1 bg-slate-50 dark:bg-slate-800/50 text-slate-700 dark:text-slate-300 py-3 rounded-xl border border-slate-200 dark:border-slate-700/50 hover:bg-slate-100 transition-colors">
                  <Briefcase className="w-5 h-5" />
                  <span className="text-xs font-bold">DSA Login</span>
                </Link>
              </div>
              
              {/* Mobile Products Accordion */}
              <div>
                <button onClick={() => toggleAccordion('products')} className="w-full flex items-center justify-between py-3 px-4 rounded-xl font-bold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <span>Products</span>
                  <ChevronDown className={`w-5 h-5 transition-transform ${openAccordion === 'products' ? 'rotate-180 text-emerald-500' : ''}`} />
                </button>
                {openAccordion === 'products' && (
                  <div className="pl-8 pr-4 py-2 space-y-2 bg-slate-50 dark:bg-slate-800/30 rounded-xl mt-1 text-sm text-slate-600 dark:text-slate-300">
                    <div className="font-bold text-emerald-600 dark:text-emerald-400 pt-2">Housing</div>
                    <Link href="/products/home-loan" onClick={closeMobileMenu} className="block py-1.5">Home Loan</Link>
                    <Link href="/products/balance-transfer" onClick={closeMobileMenu} className="block py-1.5">Balance Transfer</Link>
                    <Link href="/products/top-up-loan" onClick={closeMobileMenu} className="block py-1.5">Top-Up Loan</Link>
                    <Link href="/products/plot-loan" onClick={closeMobileMenu} className="block py-1.5">Plot Loan</Link>
                    <div className="font-bold text-emerald-600 dark:text-emerald-400 pt-2 border-t border-slate-200 dark:border-slate-700">Property & Retail</div>
                    <Link href="/products/loan-against-property" onClick={closeMobileMenu} className="block py-1.5">Loan Against Property</Link>
                    <Link href="/products/personal-loan" onClick={closeMobileMenu} className="block py-1.5">Personal Loan</Link>
                    <Link href="/products/education-loan" onClick={closeMobileMenu} className="block py-1.5">Education Loan</Link>
                    <div className="font-bold text-emerald-600 dark:text-emerald-400 pt-2 border-t border-slate-200 dark:border-slate-700">Business & Auto</div>
                    <Link href="/products/business-loan" onClick={closeMobileMenu} className="block py-1.5">Business Loan</Link>
                    <Link href="/products/working-capital" onClick={closeMobileMenu} className="block py-1.5">Working Capital</Link>
                    <Link href="/products/car-loan" onClick={closeMobileMenu} className="block py-1.5">Car Loan</Link>
                  </div>
                )}
              </div>

              {/* Mobile Compare Accordion */}
              <div>
                <button onClick={() => toggleAccordion('compare')} className="w-full flex items-center justify-between py-3 px-4 rounded-xl font-bold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <span>Compare Banks</span>
                  <ChevronDown className={`w-5 h-5 transition-transform ${openAccordion === 'compare' ? 'rotate-180 text-emerald-500' : ''}`} />
                </button>
                {openAccordion === 'compare' && (
                  <div className="pl-8 pr-4 py-2 space-y-2 bg-slate-50 dark:bg-slate-800/30 rounded-xl mt-1 text-sm text-slate-600 dark:text-slate-300">
                    <Link href="/rates" onClick={closeMobileMenu} className="block py-1.5 text-emerald-600 dark:text-emerald-400 font-bold">Live Rates</Link>
                    <Link href="/compare/interest-rates" onClick={closeMobileMenu} className="block py-1.5">Interest Table</Link>
                    <Link href="/banks/pnb" onClick={closeMobileMenu} className="block py-1.5">PNB Home Loan</Link>
                    <Link href="/banks/hdfc" onClick={closeMobileMenu} className="block py-1.5">HDFC Home Loan</Link>
                    <Link href="/banks/icici" onClick={closeMobileMenu} className="block py-1.5">ICICI Home Loan</Link>
                  </div>
                )}
              </div>

              {/* Mobile Tools Accordion */}
              <div>
                <button onClick={() => toggleAccordion('tools')} className="w-full flex items-center justify-between py-3 px-4 rounded-xl font-bold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <span>Tools & Calculators</span>
                  <ChevronDown className={`w-5 h-5 transition-transform ${openAccordion === 'tools' ? 'rotate-180 text-emerald-500' : ''}`} />
                </button>
                {openAccordion === 'tools' && (
                  <div className="pl-8 pr-4 py-2 space-y-2 bg-slate-50 dark:bg-slate-800/30 rounded-xl mt-1 text-sm text-slate-600 dark:text-slate-300">
                    <Link href="/calculator" onClick={closeMobileMenu} className="block py-1.5">EMI Calculator</Link>
                    <Link href="/eligibility" onClick={closeMobileMenu} className="block py-1.5">Eligibility Calculator</Link>
                    <Link href="/tools/interest-rate-compare" onClick={closeMobileMenu} className="block py-1.5">Interest Rate Compare</Link>
                    <Link href="/tools/balance-transfer" onClick={closeMobileMenu} className="block py-1.5">Balance Transfer</Link>
                    <Link href="/tools/prepayment" onClick={closeMobileMenu} className="block py-1.5">Prepayment Calculator</Link>
                    <Link href="/tools/stamp-duty" onClick={closeMobileMenu} className="block py-1.5">Stamp Duty</Link>
                    <Link href="/tools/tax-benefit" onClick={closeMobileMenu} className="block py-1.5">Tax Benefit Tool</Link>
                    <Link href="/tools/affordability" onClick={closeMobileMenu} className="block py-1.5">Affordability Checker</Link>
                  </div>
                )}
              </div>

              {/* Mobile Resources Accordion */}
              <div>
                <button onClick={() => toggleAccordion('resources')} className="w-full flex items-center justify-between py-3 px-4 rounded-xl font-bold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <span>Resources</span>
                  <ChevronDown className={`w-5 h-5 transition-transform ${openAccordion === 'resources' ? 'rotate-180 text-emerald-500' : ''}`} />
                </button>
                {openAccordion === 'resources' && (
                  <div className="pl-8 pr-4 py-2 space-y-2 bg-slate-50 dark:bg-slate-800/30 rounded-xl mt-1 text-sm text-slate-600 dark:text-slate-300">
                    <Link href="/blog" onClick={closeMobileMenu} className="block py-1.5 font-bold">Blog</Link>
                    <Link href="/resources/documents" onClick={closeMobileMenu} className="block py-1.5">Documents Required</Link>
                    <Link href="/resources/process" onClick={closeMobileMenu} className="block py-1.5">Loan Process Guide</Link>
                    <Link href="/resources/credit-score" onClick={closeMobileMenu} className="block py-1.5">Credit Score Guide</Link>
                    <Link href="/faq" onClick={closeMobileMenu} className="block py-1.5">FAQs</Link>
                    <Link href="/testimonials" onClick={closeMobileMenu} className="block py-1.5 text-emerald-600 dark:text-emerald-400 font-bold">Testimonials</Link>
                  </div>
                )}
              </div>
              
              <Link href="/about" onClick={closeMobileMenu} className="block w-full text-left py-3 px-4 rounded-xl font-bold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">About Us</Link>
              <Link href="/contact" onClick={closeMobileMenu} className="block w-full text-left py-3 px-4 rounded-xl font-bold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">Contact</Link>

              <div className="pt-4 pb-8 flex flex-col gap-3 px-2">
                <Link
                  href="/apply"
                  onClick={closeMobileMenu}
                  className="w-full text-center bg-gradient-to-r from-emerald-500 to-blue-600 text-white font-bold py-3.5 rounded-xl shadow-lg"
                >
                  Apply Online Now
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
