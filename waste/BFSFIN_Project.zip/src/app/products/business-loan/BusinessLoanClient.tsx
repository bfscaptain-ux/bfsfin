"use client";

import { useState } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import EMICalculator from "@/components/EMICalculator";
import FloatingSupport from "@/components/FloatingSupport";
import {
  Building2,
  CheckCircle2,
  Clock,
  ArrowRight,
  FileText,
  ShieldCheck,
  Percent,
  Wallet,
  Briefcase
} from "lucide-react";

export default function BusinessLoanClient() {
  const [activeTab, setActiveTab] = useState<'unsecured' | 'secured'>('unsecured');

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-blue-900 selection:text-white transition-colors duration-300">
      <Header />

      {/* 1. PRODUCT HERO */}
      <section className="relative bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 pt-24 lg:pt-32 pb-16 lg:pb-24 overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-50/50 dark:bg-blue-900/10 -skew-x-12 translate-x-20 pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 px-4 py-1.5 rounded-full text-xs font-bold text-blue-800 dark:text-blue-300 uppercase tracking-widest">
                <Briefcase className="w-4 h-4" /> Core Product
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 dark:text-white leading-[1.1] tracking-tight">
                Fuel Your <span className="text-blue-700 dark:text-blue-500">Business Growth.</span>
              </h1>
              
              <p className="text-lg text-slate-600 dark:text-slate-400 font-medium max-w-lg leading-relaxed">
                Whether you need working capital or funds to expand operations, our rapid business loans get you capital in as little as 48 hours.
              </p>
              
              <div className="flex flex-wrap gap-4 pt-4">
                <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-6 py-4 rounded-xl flex flex-col items-start min-w-[140px]">
                  <Percent className="w-6 h-6 text-emerald-600 dark:text-emerald-500 mb-2" />
                  <span className="text-2xl font-black text-slate-900 dark:text-white">12.50%</span>
                  <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Starting Rate</span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-6 py-4 rounded-xl flex flex-col items-start min-w-[140px]">
                  <Clock className="w-6 h-6 text-blue-600 dark:text-blue-500 mb-2" />
                  <span className="text-2xl font-black text-slate-900 dark:text-white">5 Yrs</span>
                  <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Max Tenure</span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-6 py-4 rounded-xl flex flex-col items-start min-w-[140px]">
                  <Wallet className="w-6 h-6 text-purple-600 dark:text-purple-500 mb-2" />
                  <span className="text-2xl font-black text-slate-900 dark:text-white">₹5 Cr+</span>
                  <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Max Amount</span>
                </div>
              </div>

              <div className="pt-6">
                <Link
                  href="/apply"
                  className="inline-flex px-8 py-4 bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-700 text-white font-bold text-sm rounded-lg transition-colors items-center justify-center gap-2 shadow-lg hover:shadow-blue-500/25"
                >
                  Apply Online Now <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="relative h-[500px] w-full rounded-2xl overflow-hidden shadow-2xl hidden lg:block">
              <img 
                src="https://images.unsplash.com/photo-1556761175-5973dc0f32d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                alt="Modern Business Meeting" 
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. EMI CALCULATOR */}
      <section className="py-20 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-4">Plan Your Repayment</h2>
            <p className="text-slate-600 dark:text-slate-400">Use our calculator to estimate your monthly EMI and total interest outflow.</p>
          </div>
          <EMICalculator />
        </div>
      </section>

      {/* 3. ELIGIBILITY CRITERIA & DOCUMENTS */}
      <section className="py-20 bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-4">Eligibility & Documents</h2>
            <p className="text-slate-600 dark:text-slate-400">We maintain complete transparency. Check what you need before applying.</p>
          </div>

          {/* Toggle Tabs */}
          <div className="flex justify-center mb-10">
            <div className="inline-flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
              <button 
                onClick={() => setActiveTab('unsecured')}
                className={`px-6 py-3 rounded-lg text-sm font-bold transition-all ${activeTab === 'unsecured' ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-blue-400 shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}`}
              >
                Unsecured Loan
              </button>
              <button 
                onClick={() => setActiveTab('secured')}
                className={`px-6 py-3 rounded-lg text-sm font-bold transition-all ${activeTab === 'secured' ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-blue-400 shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}`}
              >
                Secured Loan
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Eligibility Block */}
            <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-blue-600" /> Minimum Eligibility
              </h3>
              
              <ul className="space-y-6">
                <li className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center shrink-0 shadow-sm">
                    <span className="font-bold text-slate-700 dark:text-slate-300">01</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white">Business Vintage</h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Minimum 3 years of continuous business operations with valid proof.</p>
                  </div>
                </li>
                <li className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center shrink-0 shadow-sm">
                    <span className="font-bold text-slate-700 dark:text-slate-300">02</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white">Turnover & Profitability</h4>
                    {activeTab === 'unsecured' ? (
                      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Minimum ₹40 Lakhs annual turnover with positive net profit in last 2 years.</p>
                    ) : (
                      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">Flexible criteria based on the value of collateral pledged.</p>
                    )}
                  </div>
                </li>
                <li className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center shrink-0 shadow-sm">
                    <span className="font-bold text-slate-700 dark:text-slate-300">03</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white">Credit Score (CIBIL)</h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">700+ for best rates. Institutional/Company credit score is also evaluated.</p>
                  </div>
                </li>
              </ul>
            </div>

            {/* Documents Block */}
            <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                <FileText className="w-6 h-6 text-emerald-600" /> Required Documents
              </h3>
              
              <div className="space-y-4">
                <div className="p-4 bg-white dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-2">1. KYC Documents</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Pan Card & Aadhaar (Directors/Partners), Company PAN
                  </p>
                </div>
                
                <div className="p-4 bg-white dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-2">2. Financial Documents</h4>
                  <ul className="text-sm text-slate-600 dark:text-slate-400 space-y-2">
                    <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> ITR with Computation (Last 3 years)</li>
                    <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> CA Certified Audited Balance Sheet</li>
                    <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> Current Account Statement (Last 12 months)</li>
                  </ul>
                </div>

                <div className="p-4 bg-white dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-2">3. Business Proof</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" /> GST Registration, Udyam Aadhar, Incorporation Certificate
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. WHY CHOOSE BFS */}
      <section className="py-20 bg-blue-700 dark:bg-blue-900 text-white text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-black mb-12">Why Choose BFS for Your Business?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto">
                <Clock className="w-8 h-8 text-blue-200" />
              </div>
              <h3 className="text-xl font-bold">Fast Turnaround</h3>
              <p className="text-blue-100 text-sm">Approvals within 48 hours for unsecured loans, keeping your supply chain intact.</p>
            </div>
            <div className="space-y-4">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto">
                <ShieldCheck className="w-8 h-8 text-blue-200" />
              </div>
              <h3 className="text-xl font-bold">No Collateral</h3>
              <p className="text-blue-100 text-sm">Avail up to ₹1 Crore in unsecured limits without pledging any personal assets.</p>
            </div>
            <div className="space-y-4">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto">
                <Building2 className="w-8 h-8 text-blue-200" />
              </div>
              <h3 className="text-xl font-bold">Flexible Structuring</h3>
              <p className="text-blue-100 text-sm">Customized overdraft limits or term loans designed around your cash flows.</p>
            </div>
          </div>
          
          <div className="mt-16">
            <Link href="/apply" className="inline-flex px-8 py-4 bg-white text-blue-800 hover:bg-slate-100 font-bold text-sm rounded-lg transition-colors">
              Start Your Application
            </Link>
          </div>
        </div>
      </section>

      <Footer />
      <FloatingSupport />
    </div>
  );
}
