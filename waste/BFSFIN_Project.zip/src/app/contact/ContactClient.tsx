"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingSupport from "@/components/FloatingSupport";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send, 
  CheckCircle2, 
  Building2,
  PhoneCall,
  MessageSquare,
  ArrowRight,
  ShieldCheck,
  Building
} from "lucide-react";
import Link from "next/link";

export default function ContactClient() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Form State
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    loanAmount: "",
    loanType: "Home Loan",
    city: "",
    message: ""
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      // Reset after 5 seconds
      setTimeout(() => setIsSubmitted(false), 5000);
    }, 1500);
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 30 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.6 }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans selection:bg-blue-500/30">
      <Header />
      
      {/* 1. HERO SECTION */}
      <section className="relative pt-12 pb-20 lg:pt-24 lg:pb-32 overflow-hidden border-b border-slate-200 dark:border-slate-800">
        <div className="absolute inset-0 z-0 bg-white dark:bg-slate-950">
          <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-blue-500/5 dark:bg-blue-500/10 blur-[100px] rounded-full pointer-events-none transform -translate-y-1/2" />
          <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-emerald-500/5 dark:bg-emerald-500/10 blur-[100px] rounded-full pointer-events-none transform translate-y-1/3" />
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] dark:opacity-[0.05]" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-0 text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-700 dark:text-blue-400 text-[10px] sm:text-xs font-bold tracking-widest uppercase mb-6"
          >
            <MessageSquare className="w-4 h-4" /> 24/7 Support Helpdesk
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-7xl font-black text-slate-900 dark:text-white leading-tight tracking-tight mb-6"
          >
            Let's build your <br className="hidden md:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-emerald-500 dark:from-blue-400 dark:to-emerald-400">dream home together.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-base md:text-xl text-slate-600 dark:text-slate-300 leading-relaxed font-light mb-10 max-w-2xl mx-auto"
          >
            Reach out to India's top loan consultants. Whether you need a fresh home loan, balance transfer, or project funding, we are here to guide you.
          </motion.p>
        </div>
      </section>

      {/* 2. MAIN CONTENT (CONTACT INFO & FORM) */}
      <section className="py-20 relative z-20 -mt-10 lg:-mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 lg:gap-12 items-start">
            
            {/* Left Column: Contact Cards */}
            <div className="xl:col-span-5 space-y-6">
              <motion.div {...fadeInUp} transition={{ delay: 0.1 }} className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none hover:border-blue-500/50 dark:hover:border-blue-500/50 transition-colors">
                <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 rounded-2xl flex items-center justify-center mb-6">
                  <MapPin className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Headquarters</h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed mb-4">
                  Sanjay Place Commercial Hub,<br />
                  Agra, Uttar Pradesh - 282002<br />
                  India
                </p>
                <Link href="/contact/locations" className="text-blue-600 dark:text-blue-400 text-sm font-bold flex items-center gap-1 hover:gap-2 transition-all">
                  View all 7+ office locations <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <motion.div {...fadeInUp} transition={{ delay: 0.2 }} className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none hover:border-emerald-500/50 dark:hover:border-emerald-500/50 transition-colors">
                  <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center mb-4">
                    <PhoneCall className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">Direct Sales</h3>
                  <a href="tel:+919999999999" className="text-slate-600 dark:text-slate-400 text-sm hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors">
                    +91 999 999 9999
                  </a>
                </motion.div>

                <motion.div {...fadeInUp} transition={{ delay: 0.3 }} className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none hover:border-amber-500/50 dark:hover:border-amber-500/50 transition-colors">
                  <div className="w-10 h-10 bg-amber-50 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center mb-4">
                    <Mail className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">Email Us</h3>
                  <a href="mailto:info@bhardwajfinance.com" className="text-slate-600 dark:text-slate-400 text-sm hover:text-amber-600 dark:hover:text-amber-400 transition-colors">
                    info@bhardwajfinance.com
                  </a>
                </motion.div>
              </div>

              <motion.div {...fadeInUp} transition={{ delay: 0.4 }} className="bg-slate-900 dark:bg-slate-800 rounded-3xl p-6 border border-slate-800 dark:border-slate-700 shadow-xl flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-800 dark:bg-slate-700 text-slate-300 rounded-full flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white mb-1">Working Hours</h3>
                  <p className="text-slate-400 text-sm">Mon - Sat: 10:00 AM - 6:00 PM<br/>Sunday: Closed</p>
                </div>
              </motion.div>
            </div>

            {/* Right Column: Detailed Contact Form */}
            <motion.div {...fadeInUp} transition={{ delay: 0.2 }} className="xl:col-span-7 relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/10 to-emerald-500/10 rounded-[2.5rem] transform rotate-1 blur-xl" />
              <div className="relative bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 md:p-10 border border-slate-200 dark:border-slate-800 shadow-2xl shadow-slate-200/50 dark:shadow-none">
                
                <div className="flex items-center gap-3 mb-8 pb-6 border-b border-slate-100 dark:border-slate-800">
                  <Building className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  <div>
                    <h2 className="text-2xl font-black text-slate-900 dark:text-white">Request a Callback</h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Our loan experts will contact you within 24 hours.</p>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Row 1: Name & Phone */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-bold text-slate-700 dark:text-slate-300">Full Name <span className="text-red-500">*</span></label>
                      <input 
                        type="text" id="name" name="name" required
                        value={formData.name} onChange={handleChange}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm"
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-bold text-slate-700 dark:text-slate-300">Phone Number <span className="text-red-500">*</span></label>
                      <input 
                        type="tel" id="phone" name="phone" required
                        value={formData.phone} onChange={handleChange}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm"
                        placeholder="+91 99999 99999"
                      />
                    </div>
                  </div>

                  {/* Row 2: Email & City */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-bold text-slate-700 dark:text-slate-300">Email Address <span className="text-red-500">*</span></label>
                      <input 
                        type="email" id="email" name="email" required
                        value={formData.email} onChange={handleChange}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm"
                        placeholder="john@example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="city" className="text-sm font-bold text-slate-700 dark:text-slate-300">City <span className="text-red-500">*</span></label>
                      <input 
                        type="text" id="city" name="city" required
                        value={formData.city} onChange={handleChange}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm"
                        placeholder="Agra, Noida, etc."
                      />
                    </div>
                  </div>

                  {/* Row 3: Loan Type & Amount */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="loanType" className="text-sm font-bold text-slate-700 dark:text-slate-300">Loan Product <span className="text-red-500">*</span></label>
                      <select 
                        id="loanType" name="loanType" required
                        value={formData.loanType} onChange={handleChange}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm appearance-none"
                      >
                        <option value="Home Loan">Home Loan</option>
                        <option value="Loan Against Property (LAP)">Loan Against Property (LAP)</option>
                        <option value="Balance Transfer">Balance Transfer</option>
                        <option value="Project Funding">Project Funding / Construction</option>
                        <option value="Business Loan">Business Loan</option>
                        <option value="Other">Other Query</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="loanAmount" className="text-sm font-bold text-slate-700 dark:text-slate-300">Required Amount (₹)</label>
                      <input 
                        type="text" id="loanAmount" name="loanAmount"
                        value={formData.loanAmount} onChange={handleChange}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm"
                        placeholder="e.g. 50,000,00"
                      />
                    </div>
                  </div>

                  {/* Message */}
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-bold text-slate-700 dark:text-slate-300">Additional Details (Optional)</label>
                    <textarea 
                      id="message" name="message" rows={3}
                      value={formData.message} onChange={handleChange}
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-xl px-4 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm resize-none"
                      placeholder="Tell us about your property or financial requirements..."
                    />
                  </div>

                  {/* Security Note */}
                  <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-950/50 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
                    <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>Your data is 100% secure. We do not share your information with third-party marketers.</span>
                  </div>

                  {/* Submit Button */}
                  <button 
                    type="submit" 
                    disabled={isSubmitting || isSubmitted}
                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-700 text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-blue-500/25 transition-all flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">Processing <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"/></span>
                    ) : (
                      <span className="flex items-center gap-2">Send Request <Send className="w-4 h-4" /></span>
                    )}
                  </button>
                </form>

                {/* Success Overlay */}
                <AnimatePresence>
                  {isSubmitted && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm rounded-[2.5rem] flex flex-col items-center justify-center p-8 text-center"
                    >
                      <motion.div 
                        initial={{ scale: 0.5, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ type: "spring", bounce: 0.5 }}
                        className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-500 rounded-full flex items-center justify-center mb-6"
                      >
                        <CheckCircle2 className="w-10 h-10" />
                      </motion.div>
                      <h3 className="text-3xl font-black text-slate-900 dark:text-white mb-2">Request Received!</h3>
                      <p className="text-slate-600 dark:text-slate-400 mb-8 max-w-md">
                        Thank you, {formData.name || 'friend'}. One of our senior loan experts will review your request and call you shortly.
                      </p>
                      <button 
                        onClick={() => setIsSubmitted(false)}
                        className="px-6 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-bold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                      >
                        Submit Another Request
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
                
              </div>
            </motion.div>
            
          </div>
        </div>
      </section>

      <Footer />
      <FloatingSupport />
    </div>
  );
}
