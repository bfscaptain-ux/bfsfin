"use client";

import { useState, useEffect } from "react";
import { BlogPost } from "@/types/blog";
import { FAQ } from "@/types/faq";
import { Plus, LayoutDashboard, FileText, HelpCircle, LogOut, CheckCircle2, RefreshCw } from "lucide-react";
import Link from "next/link";
import Header from "@/components/Header";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<"blogs" | "faqs">("blogs");
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  // Blog Form State
  const [blogTitle, setBlogTitle] = useState("");
  const [blogExcerpt, setBlogExcerpt] = useState("");
  const [blogContent, setBlogContent] = useState("");
  const [blogImage, setBlogImage] = useState("");

  // FAQ Form State
  const [faqQuestion, setFaqQuestion] = useState("");
  const [faqAnswer, setFaqAnswer] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [blogsRes, faqsRes] = await Promise.all([
        fetch("/api/blogs"),
        fetch("/api/faqs")
      ]);
      if (blogsRes.ok) setBlogs(await blogsRes.json());
      if (faqsRes.ok) setFaqs(await faqsRes.json());
    } catch (error) {
      console.error("Failed to fetch data", error);
    }
    setLoading(false);
  };

  const handleBlogSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/blogs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: blogTitle,
          excerpt: blogExcerpt,
          content: blogContent,
          imageUrl: blogImage
        })
      });
      if (res.ok) {
        setSuccessMsg("Blog published successfully!");
        setBlogTitle(""); setBlogExcerpt(""); setBlogContent(""); setBlogImage("");
        fetchData();
        setTimeout(() => setSuccessMsg(""), 3000);
      }
    } catch (error) {
      console.error("Failed to publish blog", error);
    }
    setSubmitting(false);
  };

  const handleFaqSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/faqs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: faqQuestion,
          answer: faqAnswer
        })
      });
      if (res.ok) {
        setSuccessMsg("FAQ added successfully!");
        setFaqQuestion(""); setFaqAnswer("");
        fetchData();
        setTimeout(() => setSuccessMsg(""), 3000);
      }
    } catch (error) {
      console.error("Failed to add FAQ", error);
    }
    setSubmitting(false);
  };

  const handleBlogDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this blog?")) return;
    try {
      const res = await fetch(`/api/blogs?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        setSuccessMsg("Blog deleted successfully!");
        fetchData();
        setTimeout(() => setSuccessMsg(""), 3000);
      }
    } catch (error) {
      console.error("Failed to delete blog", error);
    }
  };

  const handleFaqDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this FAQ?")) return;
    try {
      const res = await fetch(`/api/faqs?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        setSuccessMsg("FAQ deleted successfully!");
        fetchData();
        setTimeout(() => setSuccessMsg(""), 3000);
      }
    } catch (error) {
      console.error("Failed to delete FAQ", error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Header />
      
      <div className="flex-1 flex max-w-7xl mx-auto w-full pt-10 px-4 sm:px-6 lg:px-8 gap-8">
        
        {/* Sidebar */}
        <div className="w-64 shrink-0">
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sticky top-28 shadow-sm">
            <h2 className="font-black text-xl mb-6 text-slate-900 dark:text-white flex items-center gap-2">
              <LayoutDashboard className="w-5 h-5 text-emerald-500" /> Admin CMS
            </h2>
            
            <nav className="space-y-2">
              <button 
                onClick={() => setActiveTab("blogs")}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'blogs' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'}`}
              >
                <FileText className="w-4 h-4" /> Manage Blogs
              </button>
              <button 
                onClick={() => setActiveTab("faqs")}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'faqs' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'}`}
              >
                <HelpCircle className="w-4 h-4" /> Manage FAQs
              </button>
            </nav>

            <div className="mt-12 pt-6 border-t border-slate-100 dark:border-slate-800">
              <Link href="/" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all">
                <LogOut className="w-4 h-4" /> Logout
              </Link>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 space-y-8 pb-20">
          
          {successMsg && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-500/30 dark:text-emerald-300 px-6 py-4 rounded-xl flex items-center gap-3 shadow-sm">
              <CheckCircle2 className="w-5 h-5" />
              <span className="font-bold">{successMsg}</span>
            </div>
          )}

          {/* Manage Blogs Tab */}
          {activeTab === "blogs" && (
            <div className="space-y-8">
              {/* Add Blog Form */}
              <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm">
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                  <Plus className="w-6 h-6 text-emerald-500" /> Create New Blog
                </h3>
                <form onSubmit={handleBlogSubmit} className="space-y-5">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Blog Title *</label>
                    <input required type="text" value={blogTitle} onChange={(e) => setBlogTitle(e.target.value)} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="e.g. 5 Tips for Fast Home Loan Approval" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Short Excerpt</label>
                    <input type="text" value={blogExcerpt} onChange={(e) => setBlogExcerpt(e.target.value)} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="A brief summary for the preview card..." />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Image URL</label>
                    <input type="url" value={blogImage} onChange={(e) => setBlogImage(e.target.value)} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="https://unsplash.com/..." />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Full Content *</label>
                    <textarea required value={blogContent} onChange={(e) => setBlogContent(e.target.value)} rows={6} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Write your blog post here..."></textarea>
                  </div>
                  <button type="submit" disabled={submitting} className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-8 py-3.5 rounded-xl transition-all shadow-lg flex items-center gap-2">
                    {submitting ? <RefreshCw className="w-5 h-5 animate-spin" /> : 'Publish Blog Post'}
                  </button>
                </form>
              </div>

              {/* Existing Blogs List */}
              <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm">
                <h3 className="text-xl font-black text-slate-900 dark:text-white mb-6">Published Blogs</h3>
                {loading ? (
                  <p className="text-slate-500">Loading blogs...</p>
                ) : (
                  <div className="space-y-4">
                    {blogs.map(blog => (
                      <div key={blog.id} className="flex justify-between items-center p-4 border border-slate-100 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900">
                        <div>
                          <h4 className="font-bold text-slate-800 dark:text-slate-200">{blog.title}</h4>
                          <p className="text-sm text-slate-500">{blog.date} • {blog.author}</p>
                        </div>
                        <button onClick={() => handleBlogDelete(blog.id)} className="text-red-500 text-sm font-bold hover:underline">Delete</button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Manage FAQs Tab */}
          {activeTab === "faqs" && (
            <div className="space-y-8">
              {/* Add FAQ Form */}
              <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm">
                <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                  <Plus className="w-6 h-6 text-blue-500" /> Add New FAQ
                </h3>
                <form onSubmit={handleFaqSubmit} className="space-y-5">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Question *</label>
                    <input required type="text" value={faqQuestion} onChange={(e) => setFaqQuestion(e.target.value)} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g. What is the minimum CIBIL score?" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Answer *</label>
                    <textarea required value={faqAnswer} onChange={(e) => setFaqAnswer(e.target.value)} rows={4} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Write the answer here..."></textarea>
                  </div>
                  <button type="submit" disabled={submitting} className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-8 py-3.5 rounded-xl transition-all shadow-lg flex items-center gap-2">
                    {submitting ? <RefreshCw className="w-5 h-5 animate-spin" /> : 'Publish FAQ'}
                  </button>
                </form>
              </div>

              {/* Existing FAQs List */}
              <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm">
                <h3 className="text-xl font-black text-slate-900 dark:text-white mb-6">Active FAQs</h3>
                {loading ? (
                  <p className="text-slate-500">Loading FAQs...</p>
                ) : (
                  <div className="space-y-4">
                    {faqs.map(faq => (
                      <div key={faq.id} className="p-4 border border-slate-100 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900 group">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-slate-800 dark:text-slate-200">{faq.question}</h4>
                          <button onClick={() => handleFaqDelete(faq.id)} className="text-red-500 text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity">Delete</button>
                        </div>
                        <p className="text-sm text-slate-600 dark:text-slate-400">{faq.answer}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
