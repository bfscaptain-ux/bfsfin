"use client";

import { useState } from "react";
import { FileText, Plus, Edit2, Trash2 } from "lucide-react";

export default function AdminArticlesCMS() {
  const [articles, setArticles] = useState([
    { id: "1", title: "Tax Benefits of Home Loans in 2026: Save Up to ₹5 Lakhs", category: "Tax Guidance", author: "Adv. Praveen Bhardwaj", date: "May 1, 2026" },
    { id: "2", title: "Home Loan Balance Transfer Guide: Save Millions on Interest", category: "Balance Transfer", author: "Adv. Praveen Bhardwaj", date: "Apr 28, 2026" },
    { id: "3", title: "5 Proven Ways to Boost Your CIBIL Score Above 750 Fast", category: "Credit Rating", author: "Adv. Praveen Bhardwaj", date: "Apr 20, 2026" },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Tax Guidance");

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;
    setArticles([
      { id: Date.now().toString(), title, category, author: "Adv. Praveen Bhardwaj", date: "Just now" },
      ...articles
    ]);
    setTitle("");
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    setArticles(articles.filter(a => a.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-3xl">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <FileText className="w-6 h-6 text-emerald-400" /> Blog &amp; Educational Resources CMS
          </h1>
          <p className="text-xs text-slate-400 mt-1">Publish guides and articles to educate homebuyers and improve SEO ranking.</p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-lg transition"
        >
          <Plus className="w-4 h-4" /> Publish New Article
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Article Title</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Author</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {articles.map((a) => (
                <tr key={a.id} className="hover:bg-slate-800/40">
                  <td className="py-3.5 px-4 font-bold text-white">{a.title}</td>
                  <td className="py-3.5 px-4">
                    <span className="bg-blue-500/20 text-blue-300 font-bold px-2 py-0.5 rounded border border-blue-500/30 text-[10px]">
                      {a.category}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-300">{a.author}</td>
                  <td className="py-3.5 px-4 text-slate-400">{a.date}</td>
                  <td className="py-3.5 px-4">
                    <button onClick={() => handleDelete(a.id)} className="text-red-400 hover:text-red-300 p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <h3 className="text-lg font-bold text-white">Publish New Guide</h3>
            <form onSubmit={handleCreate} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Article Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. How to Save Tax on Home Loan"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none"
                >
                  <option value="Tax Guidance">Tax Guidance</option>
                  <option value="Balance Transfer">Balance Transfer</option>
                  <option value="Credit Rating">Credit Rating</option>
                </select>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button type="button" onClick={() => setShowModal(false)} className="bg-slate-800 text-slate-300 px-4 py-2 rounded-xl">Cancel</button>
                <button type="submit" className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2 rounded-xl">Publish</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
