import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

const dataFilePath = path.join(process.cwd(), 'src', 'data', 'faqs.json');

export async function GET() {
  try {
    const fileContents = await fs.readFile(dataFilePath, 'utf8');
    const faqs = JSON.parse(fileContents);
    return NextResponse.json(faqs);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch FAQs' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const newFaq = await request.json();
    
    // Validate
    if (!newFaq.question || !newFaq.answer) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Read existing
    const fileContents = await fs.readFile(dataFilePath, 'utf8');
    const faqs = JSON.parse(fileContents);
    
    // Add new
    const faqEntry = {
      id: Date.now().toString(),
      question: newFaq.question,
      answer: newFaq.answer
    };
    
    faqs.push(faqEntry); // Add to end
    
    // Save
    await fs.writeFile(dataFilePath, JSON.stringify(faqs, null, 2));
    
    return NextResponse.json(faqEntry, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create FAQ' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Missing FAQ ID' }, { status: 400 });
    }

    const fileContents = await fs.readFile(dataFilePath, 'utf8');
    const faqs = JSON.parse(fileContents);
    
    const initialLength = faqs.length;
    const updatedFaqs = faqs.filter((faq: any) => faq.id !== id);

    if (updatedFaqs.length === initialLength) {
      return NextResponse.json({ error: 'FAQ not found' }, { status: 404 });
    }

    await fs.writeFile(dataFilePath, JSON.stringify(updatedFaqs, null, 2));
    return NextResponse.json({ success: true, message: 'FAQ deleted' });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete FAQ' }, { status: 500 });
  }
}
