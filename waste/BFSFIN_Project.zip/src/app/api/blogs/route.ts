import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

const dataFilePath = path.join(process.cwd(), 'src', 'data', 'blogs.json');

export async function GET() {
  try {
    const fileContents = await fs.readFile(dataFilePath, 'utf8');
    const blogs = JSON.parse(fileContents);
    return NextResponse.json(blogs);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch blogs' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const newBlog = await request.json();
    
    // Validate
    if (!newBlog.title || !newBlog.content) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Read existing
    const fileContents = await fs.readFile(dataFilePath, 'utf8');
    const blogs = JSON.parse(fileContents);
    
    // Add new
    const blogEntry = {
      id: Date.now().toString(),
      title: newBlog.title,
      excerpt: newBlog.excerpt || '',
      content: newBlog.content,
      imageUrl: newBlog.imageUrl || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      date: new Date().toISOString().split('T')[0],
      author: newBlog.author || 'Admin'
    };
    
    blogs.unshift(blogEntry); // Add to beginning
    
    // Save
    await fs.writeFile(dataFilePath, JSON.stringify(blogs, null, 2));
    
    return NextResponse.json(blogEntry, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create blog' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Missing blog ID' }, { status: 400 });
    }

    const fileContents = await fs.readFile(dataFilePath, 'utf8');
    const blogs = JSON.parse(fileContents);
    
    const initialLength = blogs.length;
    const updatedBlogs = blogs.filter((blog: any) => blog.id !== id);

    if (updatedBlogs.length === initialLength) {
      return NextResponse.json({ error: 'Blog not found' }, { status: 404 });
    }

    await fs.writeFile(dataFilePath, JSON.stringify(updatedBlogs, null, 2));
    return NextResponse.json({ success: true, message: 'Blog deleted' });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete blog' }, { status: 500 });
  }
}
