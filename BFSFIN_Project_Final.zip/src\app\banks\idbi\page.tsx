import BankPageTemplate from "@/components/templates/BankPageTemplate";
import { banksData } from "@/data/banksData";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: banksData["idbi"].seoTitle,
  description: banksData["idbi"].seoDescription,
};

export default function IDBIPage() {
  return <BankPageTemplate data={banksData["idbi"]} />;
}
