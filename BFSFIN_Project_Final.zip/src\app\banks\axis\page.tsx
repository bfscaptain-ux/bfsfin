import BankPageTemplate from "@/components/templates/BankPageTemplate";
import { banksData } from "@/data/banksData";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: banksData["axis"].seoTitle,
  description: banksData["axis"].seoDescription,
};

export default function AxisBankPage() {
  return <BankPageTemplate data={banksData["axis"]} />;
}
