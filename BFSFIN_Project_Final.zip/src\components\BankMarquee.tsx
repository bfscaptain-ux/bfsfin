"use client";

import { motion } from "framer-motion";

const bankLogos = [
  { name: "HDFC Bank",         src: "/bank logo/hdfc bank logo bhardwaj finance.jpg" },
  { name: "ICICI Bank",        src: "/bank logo/icici.jpg" },
  { name: "Axis Bank",         src: "/bank logo/axis.jpg" },
  { name: "Kotak Mahindra",    src: "/bank logo/kotak.jpg" },
  { name: "Punjab National",   src: "/bank logo/pnb.jpg" },
  { name: "Bank of Baroda",    src: "/bank logo/bank of baroda.jpg" },
  { name: "AU Small Finance",  src: "/bank logo/au bank.jpg" },
  { name: "Canara Bank",       src: "/bank logo/canara.jpg" },
  { name: "Union Bank",        src: "/bank logo/union.jpg" },
];

// Duplicate so the loop feels seamless
const logos = [...bankLogos, ...bankLogos];

export default function BankMarquee() {
  return (
    <div className="relative z-10 w-full overflow-hidden border-b border-slate-200/60 dark:border-slate-800/60 py-5 bg-white/60 dark:bg-slate-950/60 backdrop-blur-md">

      {/* Left & Right edge fade */}
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-white dark:from-slate-950 to-transparent z-10" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-white dark:from-slate-950 to-transparent z-10" />

      {/* Single scrolling row */}
      <motion.div
        className="flex items-center gap-6 w-max"
        animate={{ x: [0, "-50%"] }}
        transition={{ repeat: Infinity, ease: "linear", duration: 32 }}
      >
        {logos.map((logo, idx) => (
          <div
            key={idx}
            className="
              flex-shrink-0 flex items-center justify-center
              h-12 w-32 px-3 rounded-xl
              bg-white dark:bg-slate-900
              border border-slate-100 dark:border-slate-800
              shadow-sm
              hover:shadow-md hover:border-emerald-300 dark:hover:border-emerald-700
              transition-all duration-300 group cursor-default
            "
          >
            <img
              src={logo.src}
              alt={logo.name}
              title={logo.name}
              className="max-h-8 max-w-full object-contain group-hover:scale-105 transition-transform duration-300"
            />
          </div>
        ))}
      </motion.div>
    </div>
  );
}
