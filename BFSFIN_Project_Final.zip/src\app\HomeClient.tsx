"use client";

import { useState } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import LiveTicker from "@/components/LiveTicker";
import QuickEligibility from "@/components/QuickEligibility";
import FloatingSupport from "@/components/FloatingSupport";
import BankMarquee from "@/components/BankMarquee";
import CoreServices from "@/components/CoreServices";
import BfsAdvantage from "@/components/BfsAdvantage";
import RentVsBuyCalculator from "@/components/RentVsBuyCalculator";
import ProcessTimeline from "@/components/ProcessTimeline";
import ModernBackground from "@/components/ModernBackground";
import SharedContactForm from "@/components/SharedContactForm";

import {
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Star,
  Quote,
  MapPin,
  PhoneCall,
  Calculator,
  HeartHandshake,
  ChevronDown
} from "lucide-react";

export default function HomeClient() {
  const [loanAmount, setLoanAmount] = useState(2500000);
  
  return (
    <div className="min-h-screen flex flex-col bg-transparent text-slate-900 dark:text-slate-100 font-sans selection:bg-emerald-900 selection:text-white transition-colors duration-500 relative">
      
      {/* GEN-Z INTERACTIVE BACKGROUND */}
      <ModernBackground />

      <Header />

      {/* 1. HERO SECTION - Perfectly responsive on every screen size */}
      <section className="relative min-h-[calc(100svh-120px)] overflow-hidden flex items-center bg-transparent z-10 py-12 lg:py-0">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img 
            src="/hero_image.jpg" 
            alt="Bhardwaj Finance Hero Background" 
            className="w-full h-full object-cover object-[70%_center] lg:object-center"
          />
          {/* Strong gradient on LEFT half so text stays crisp and readable */}
          <div className="absolute inset-0 bg-gradient-to-r from-white via-white/88 to-white/10 dark:from-slate-950 dark:via-slate-950/88 dark:to-slate-950/10"></div>
          {/* Very subtle bottom fade for smooth section transition */}
          <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-slate-50/70 dark:from-slate-950/70 to-transparent"></div>
        </div>

        {/* BFS Logo watermark - bottom-right behind content */}
        <div className="absolute bottom-0 right-0 pointer-events-none select-none translate-x-1/4 translate-y-1/4 opacity-[0.07] dark:opacity-[0.12] z-[1]">
          <img src="/logo.png" alt="" className="w-[40vw] max-w-[560px] min-w-[260px] h-auto object-contain drop-shadow-[0_0_40px_rgba(16,185,129,0.3)]" />
        </div>

        {/* Content — centred vertically, uses the full viewport height */}
        <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-10 xl:px-16 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 xl:gap-12 items-center">
            
            {/* LEFT: Copy */}
            <div className="lg:col-span-7 xl:col-span-6 space-y-4 xl:space-y-5 animate-in slide-in-from-bottom-8 fade-in duration-1000 fill-mode-both">
              
              <div className="inline-flex items-center gap-2 bg-white/60 dark:bg-slate-900/60 backdrop-blur-md border border-slate-200/60 dark:border-slate-800/60 px-3 py-1.5 rounded-full text-[11px] font-bold text-slate-700 dark:text-slate-300 shadow-sm">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-500" />
                RBI Registered & Verified Partners
              </div>
              
              <h1 className="
                text-[clamp(2.2rem,5vw,4.2rem)]
                font-extrabold text-slate-900 dark:text-white
                leading-[1.1] tracking-tight
              ">
                Your Dream Home,
                <br />
                <span className="inline-flex flex-wrap items-center gap-x-2 mt-1">
                  <span className="text-emerald-600 dark:text-emerald-400">Funded in</span>
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-500 to-orange-500 dark:from-amber-400 dark:to-orange-400">
                    5 Days.
                  </span>
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-amber-500 dark:text-amber-400 shrink-0 w-[clamp(1.8rem,3vw,2.8rem)] h-[clamp(1.8rem,3vw,2.8rem)]">
                    <path d="M7 13s2 3 5 3 5-3 5-3" />
                    <line x1="8" y1="9" x2="8.01" y2="9" />
                    <line x1="16" y1="9" x2="16.01" y2="9" />
                  </svg>
                </span>
              </h1>
              
              <div className="flex flex-col gap-2.5 pt-1">
                {[
                  "Lowest Interest Rates Guaranteed (from 6.50%)",
                  "Zero Processing Fees for Direct Applications",
                  "Doorstep Document Pickup & 100% Digital Process",
                ].map((point, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center shadow-sm">
                      <CheckCircle2 className="w-3 h-3 text-white" />
                    </div>
                    <span className="text-[clamp(13px,1.4vw,15px)] font-bold text-slate-800 dark:text-slate-100 tracking-tight">{point}</span>
                  </div>
                ))}
              </div>
              
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 pt-2">
                <Link
                  href="/apply"
                  className="relative group w-full sm:w-auto px-7 py-3.5 bg-emerald-600 dark:bg-emerald-500 hover:bg-emerald-700 dark:hover:bg-emerald-600 text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 hover:-translate-y-0.5 overflow-hidden"
                >
                  <div className="absolute inset-0 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"></div>
                  Apply For Loan <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>

                <div className="flex items-center gap-2.5 bg-white/70 dark:bg-white/10 backdrop-blur-md px-3.5 py-2 rounded-xl shadow-sm border border-slate-200/60 dark:border-white/20">
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1 mb-0.5">
                      <img src="https://cdn-icons-png.flaticon.com/512/2991/2991148.png" alt="Google" className="w-3 h-3 mr-0.5" />
                      {[1,2,3,4,5].map((star) => (
                        <Star key={star} className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-300 leading-none">
                      <strong className="text-slate-900 dark:text-white font-black">4.9/5</strong> (1,200+ reviews)
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <a href="tel:7900979001" className="inline-flex items-center gap-2 text-[13px] font-semibold text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white transition-colors bg-white/50 dark:bg-black/20 backdrop-blur-md px-3.5 py-2 rounded-lg border border-slate-200/40 dark:border-white/10 group">
                  <div className="relative flex h-3.5 w-3.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <PhoneCall className="relative inline-flex rounded-full w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform" />
                  </div>
                  Prefer talking to an expert? Call: <span className="font-bold text-slate-900 dark:text-white">7900-979-001</span>
                </a>
              </div>
            </div>

            {/* RIGHT: EMI Card */}
            <div className="lg:col-span-5 xl:col-span-6 relative w-full animate-in slide-in-from-right-8 fade-in duration-1000 delay-200 fill-mode-both flex justify-center lg:justify-end">
              <div className="w-full max-w-[380px] xl:max-w-[420px] bg-white/85 dark:bg-slate-900/85 backdrop-blur-2xl p-6 rounded-3xl shadow-2xl border border-white/70 dark:border-slate-700/50 relative z-20">
                <div className="absolute -top-3 -right-3 bg-gradient-to-br from-amber-400 to-orange-500 p-2 rounded-xl shadow-xl border border-amber-300/50 flex items-center gap-1.5 z-30 transform rotate-3 hover:rotate-0 transition-all duration-300 animate-[bounce_3s_infinite]">
                  <HeartHandshake className="w-5 h-5 text-white animate-pulse" />
                  <div className="pr-1">
                    <p className="text-[7px] uppercase font-bold text-amber-100 tracking-wider leading-tight">Success Rate</p>
                    <p className="font-black text-white text-[10px] leading-tight">98% Approvals</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 bg-emerald-500/10 dark:bg-emerald-900/30 rounded-xl flex items-center justify-center border border-emerald-500/20 dark:border-emerald-800/50">
                    <Calculator className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-[15px]">Quick EMI Estimate</h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">Move slider to calculate</p>
                  </div>
                </div>

                <div className="space-y-5">
                  <div>
                    <div className="flex justify-between items-end mb-2">
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Loan Amount</span>
                      <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">₹{(loanAmount / 100000).toFixed(1)} Lakhs</span>
                    </div>
                    <input 
                      type="range" 
                      min="1000000" 
                      max="10000000" 
                      step="500000"
                      value={loanAmount}
                      onChange={(e) => setLoanAmount(Number(e.target.value))}
                      className="w-full h-2 bg-slate-200/60 dark:bg-slate-700/60 rounded-lg appearance-none cursor-pointer accent-emerald-600 transition-all"
                    />
                  </div>

                  <div className="bg-slate-50/80 dark:bg-slate-950/50 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-800/60 flex justify-between items-center backdrop-blur-sm">
                    <div>
                      <p className="text-[9px] uppercase font-bold text-slate-500 dark:text-slate-400 tracking-wider mb-1">Est. Monthly EMI</p>
                      <p className="text-2xl font-black text-slate-900 dark:text-white">
                        ₹{Math.round((loanAmount * 0.065 / 12) / (1 - Math.pow(1 + 0.065 / 12, -240))).toLocaleString('en-IN')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[9px] uppercase font-bold text-slate-500 dark:text-slate-400 tracking-wider mb-1">Interest Rate</p>
                      <p className="text-base font-bold text-emerald-600 dark:text-emerald-400 flex items-center justify-end gap-1.5">
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                        </span>
                        6.50% p.a.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NEW MODERN SECTIONS WITH TRANSPARENT WRAPPERS */}
      <BankMarquee />
      <CoreServices />
      <BfsAdvantage />
      <LiveTicker />

      <section className="py-20 relative z-10 border-y border-slate-200/30 dark:border-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <QuickEligibility />
        </div>
      </section>

      <RentVsBuyCalculator />
      <ProcessTimeline />

      {/* FOUNDER & AUTHORITY MESSAGE */}
      <section className="py-24 relative z-10 border-t border-slate-200/30 dark:border-slate-800/30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-2xl border border-white/50 dark:border-slate-800/50 rounded-[2.5rem] p-10 md:p-16 flex flex-col md:flex-row gap-12 items-center relative overflow-hidden transition-shadow hover:shadow-2xl hover:shadow-blue-900/10 duration-500">
            {/* BFS Logo watermark inside the founder card */}
            <div className="absolute bottom-0 right-0 pointer-events-none select-none opacity-[0.05] dark:opacity-[0.08] translate-x-1/4 translate-y-1/4">
              <img src="/logo.png" alt="" className="w-80 h-80 object-contain" />
            </div>
            <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none">
              <Quote className="w-64 h-64 text-slate-900 dark:text-white" />
            </div>
            
            <div className="w-48 h-48 md:w-64 md:h-64 shrink-0 rounded-full overflow-hidden border-4 border-white/80 dark:border-slate-800 shadow-xl relative z-10">
              <img 
                src="/praveen_bhardwaj.png" 
                alt="Adv. Praveen Bhardwaj" 
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="space-y-6 text-center md:text-left relative z-10">
              <Quote className="w-10 h-10 text-emerald-500 dark:text-emerald-400 mx-auto md:mx-0 opacity-80" />
              <h3 className="text-2xl md:text-4xl font-extrabold text-slate-900 dark:text-white leading-tight tracking-tight">
                "We don't just secure loans; we legally vet your lifetime investment. Total transparency, zero hidden brokerage."
              </h3>
              <div className="pt-4 border-t border-slate-200/50 dark:border-slate-700/50 inline-block w-full md:w-auto">
                <p className="text-xl font-black text-slate-900 dark:text-white">Adv. Praveen Bhardwaj</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest mt-1">Founder & Managing Director, BFS</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HEAD OFFICE / CONTACT BLOCK - Adaptive Glass */}
      <section className="py-24 relative z-10 overflow-hidden border-t border-slate-200/50 dark:border-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="bg-white/60 dark:bg-slate-900/40 backdrop-blur-xl p-10 rounded-[2.5rem] border border-white/80 dark:border-slate-800/50 shadow-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 dark:bg-slate-800/60 border border-blue-100 dark:border-slate-700/50 text-[11px] font-bold uppercase tracking-widest text-blue-600 dark:text-slate-400 mb-6 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                Physical Presence
              </div>
              <h3 className="text-4xl md:text-5xl font-extrabold mb-8 leading-tight tracking-tight text-slate-900 dark:text-white">Visit Our <br/>Agra Head Office</h3>
              <p className="text-slate-600 dark:text-slate-400 mb-10 max-w-md text-lg leading-relaxed">
                While we process loans digitally across India, our doors are always open for face-to-face consultations. 
              </p>
              
              <div className="space-y-8">
                <div className="flex items-start gap-5 group">
                  <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800/80 flex items-center justify-center shrink-0 border border-slate-200 dark:border-slate-700/50 shadow-sm group-hover:bg-emerald-50 dark:group-hover:bg-emerald-500/10 transition-colors">
                    <MapPin className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-lg group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">Corporate Headquarters</h4>
                    <p className="text-slate-600 dark:text-slate-400 mt-2 leading-relaxed text-sm font-medium">12/34, Financial District, Sanjay Place,<br/>Agra, Uttar Pradesh 282002</p>
                  </div>
                </div>
                <div className="flex items-start gap-5 group">
                  <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800/80 flex items-center justify-center shrink-0 border border-slate-200 dark:border-slate-700/50 shadow-sm group-hover:bg-blue-50 dark:group-hover:bg-blue-500/10 transition-colors">
                    <PhoneCall className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-lg group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">Direct Hotline</h4>
                    <p className="text-slate-600 dark:text-slate-400 mt-2 leading-relaxed text-sm font-medium">1800-XXX-XXXX (Toll Free)<br/>Available Mon-Sat, 10 AM to 7 PM</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-900 dark:bg-slate-900/80 backdrop-blur-2xl p-10 rounded-[2.5rem] border border-slate-800 shadow-2xl relative text-white lg:min-h-[500px]">
              <h4 className="font-extrabold text-3xl mb-2 text-white tracking-tight">Request a Callback</h4>
              <p className="text-slate-400 text-sm mb-8">Our loan experts will reach out to you within 10 minutes.</p>
              <SharedContactForm variant="dark" />
            </div>
          </div>
        </div>
      </section>

      {/* CLIENT TESTIMONIALS */}
      <section className="py-24 relative z-10 border-t border-slate-200/30 dark:border-slate-800/30 overflow-hidden">
        {/* BFS Logo watermark centred behind all cards */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none select-none opacity-[0.03] dark:opacity-[0.05]">
          <img src="/logo.png" alt="" className="w-[600px] h-[600px] object-contain" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-20">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 dark:bg-amber-500/20 border border-amber-500/20 dark:border-amber-500/30 text-[11px] font-bold uppercase tracking-widest text-amber-600 dark:text-amber-500 mb-6 backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              Wall of Love
            </div>
            <h3 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-6 tracking-tight">Client Success Stories</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: "Rahul S.", location: "Agra", text: "Got my PNB home loan sanctioned in exactly 4 days. BFS handled all the paperwork and legal checks effortlessly." },
              { name: "Sneha M.", location: "Noida", text: "I transferred my existing loan through BFS and reduced my interest rate by a massive margin. Their team is highly professional." },
              { name: "Amit K.", location: "Mathura", text: "The zero hidden fee promise is real! Everything was transparent from day one till the final disbursal." }
            ].map((review, idx) => (
              <div key={idx} className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl p-10 rounded-[2rem] border border-white/50 dark:border-slate-800/50 shadow-lg hover:shadow-2xl hover:shadow-emerald-900/10 transition-all duration-500 relative group flex flex-col">
                <div className="flex gap-1 mb-8">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />)}
                </div>
                <p className="text-slate-700 dark:text-slate-300 mb-10 font-medium text-lg leading-relaxed flex-grow">"{review.text}"</p>
                <div className="flex items-center gap-4 border-t border-slate-200/50 dark:border-slate-800/50 pt-6">
                  <div className="w-12 h-12 rounded-full bg-white dark:bg-slate-800 flex items-center justify-center font-black text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 shadow-sm">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white">{review.name}</h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold mt-1">{review.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ SECTION */}
      <section className="py-24 relative z-10 border-t border-slate-200/30 dark:border-slate-800/30 overflow-hidden">
        {/* BFS Logo watermark - bottom left accent */}
        <div className="absolute bottom-0 left-0 pointer-events-none select-none opacity-[0.04] dark:opacity-[0.06] -translate-x-1/4 translate-y-1/4">
          <img src="/logo.png" alt="" className="w-72 h-72 object-contain" />
        </div>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h3 className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">Frequently Asked Questions</h3>
          </div>
          <div className="space-y-4">
            {[
              { q: "What is the minimum CIBIL score required for a home loan?", a: "Ideally, a CIBIL score of 750 or above is preferred by most partner banks for the lowest interest rates (starting at 6.50%). However, we can also process loans for scores between 650-749 with slight variations in the rate." },
              { q: "How does the '5-Day Sanction Guarantee' work?", a: "Once you submit all the required documents (KYC, Income Proof, and Property Papers), our dedicated team processes your file directly through priority banking channels. We ensure a sanction letter is generated within 5 working days." },
              { q: "Do you charge any hidden processing fees?", a: "No. BFS operates with complete transparency. We do not charge any hidden brokerage fees from our clients. You only pay the standard bank processing fee directly to the lending bank." },
              { q: "Can I transfer my existing high-interest loan to a new bank?", a: "Yes! Our Balance Transfer facility allows you to shift your existing loan to a new bank at a much lower interest rate (starting at 6.45%), saving you lakhs in interest over the tenure." }
            ].map((faq, idx) => (
              <details key={idx} className="group bg-white/50 dark:bg-slate-900/40 backdrop-blur-md border border-white/50 dark:border-slate-800/50 rounded-[1.5rem] [&_summary::-webkit-details-marker]:hidden transition-all duration-300 open:shadow-lg open:shadow-blue-900/5 open:bg-white/80 dark:open:bg-slate-900/80">
                <summary className="flex cursor-pointer items-center justify-between gap-4 p-6 sm:p-8 text-slate-900 dark:text-white font-bold text-base sm:text-lg select-none">
                  {faq.q}
                  <span className="shrink-0 text-slate-400 group-open:-rotate-180 transition-transform duration-300 bg-white dark:bg-slate-800 p-2 rounded-full shadow-sm">
                    <ChevronDown className="w-5 h-5" />
                  </span>
                </summary>
                <div className="px-6 sm:px-8 pb-8 text-slate-700 dark:text-slate-300 leading-relaxed text-sm sm:text-base border-t border-slate-200/50 dark:border-slate-800/50 pt-4 font-medium">
                  {faq.a}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* STRONG FINAL CTA - Adaptive Glass */}
      <section className="relative py-32 text-center overflow-hidden border-t border-slate-200/50 dark:border-slate-800/30 z-10">
        <div className="max-w-4xl mx-auto px-4 relative z-10 bg-white/80 dark:bg-slate-900/80 backdrop-blur-3xl border border-slate-200/80 dark:border-slate-800 p-12 md:p-20 rounded-[3rem] shadow-2xl dark:shadow-[0_0_100px_rgba(16,185,129,0.15)]">
          
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[11px] font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400 mb-8 relative z-10 shadow-sm">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            Start Today
          </div>
          <h2 className="text-4xl md:text-6xl font-black text-slate-900 dark:text-white mb-6 leading-tight tracking-tight relative z-10">
            Your dream home is just <br/> 
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-teal-500 dark:from-emerald-400 dark:to-teal-400">5 days away.</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-300 text-lg sm:text-xl mb-12 font-medium max-w-2xl mx-auto leading-relaxed relative z-10">
            Join thousands of families across India who secured their future with BFS safely and transparently.
          </p>
          <Link href="/apply" className="relative z-10 inline-flex items-center gap-3 px-10 py-5 bg-emerald-600 text-white font-bold text-lg rounded-2xl hover:bg-emerald-500 hover:scale-[1.02] transition-all shadow-[0_0_40px_rgba(16,185,129,0.3)] hover:shadow-[0_0_60px_rgba(16,185,129,0.5)]">
            Start Digital Application
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      <Footer />
      <FloatingSupport />
    </div>
  );
}
