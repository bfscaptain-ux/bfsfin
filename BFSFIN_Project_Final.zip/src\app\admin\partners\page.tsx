"use client";

import { useState } from "react";
import { DollarSign, CheckCircle2, Clock, Users, ShieldCheck } from "lucide-react";

export default function AdminPartnersPage() {
  const [payouts, setPayouts] = useState([
    { id: "p1", dealer: "Patel & Co. (Amit Patel)", lead: "Rajesh Kumar", loanAmount: "₹30,00,000", commission: "₹15,000", status: "PAID", date: "May 10" },
    { id: "p2", dealer: "Patel & Co. (Amit Patel)", lead: "Amit Patel", loanAmount: "₹50,00,000", commission: "₹25,000", status: "PAID", date: "May 15" },
    { id: "p3", dealer: "Patel & Co. (Amit Patel)", lead: "Priya Sharma", loanAmount: "₹25,00,000", commission: "₹12,000", status: "PENDING", date: "May 20" },
  ]);

  const handleApprovePayout = (id: string) => {
    setPayouts(payouts.map(p => p.id === id ? { ...p, status: "PAID" } : p));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-3xl">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-emerald-400" /> Partner Commission &amp; Payout Manager
          </h1>
          <p className="text-xs text-slate-400 mt-1">Approve partner payouts, track dealer referral performance, and manage commission rules.</p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Dealer Partner</th>
                <th className="py-3 px-4">Referred Client</th>
                <th className="py-3 px-4">Loan Amount</th>
                <th className="py-3 px-4">Commission</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {payouts.map((p) => (
                <tr key={p.id} className="hover:bg-slate-800/40">
                  <td className="py-3.5 px-4 font-bold text-white">{p.dealer}</td>
                  <td className="py-3.5 px-4 text-slate-300">{p.lead}</td>
                  <td className="py-3.5 px-4 font-semibold text-emerald-400">{p.loanAmount}</td>
                  <td className="py-3.5 px-4 font-black text-blue-300">{p.commission}</td>
                  <td className="py-3.5 px-4 font-bold">
                    {p.status === "PAID" ? (
                      <span className="text-emerald-400">PAID ✅</span>
                    ) : (
                      <span className="text-emerald-400">PENDING ⏳</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    {p.status === "PENDING" && (
                      <button
                        onClick={() => handleApprovePayout(p.id)}
                        className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-3 py-1 rounded-lg text-[10px]"
                      >
                        Approve Payout
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
